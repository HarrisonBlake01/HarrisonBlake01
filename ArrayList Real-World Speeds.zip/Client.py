class Client:
    def __init__(self, client_id=0, first_name="unknown", last_name="unknown", phone="unknown", email="unknown"):
        self.__client_id = client_id
        self.__first_name = first_name
        self.__last_name = last_name
        self.__phone = phone
        self.__email = email

#classes that compare objects must implement __eq__ and __lt__
#__lt__ means less than and returns a boolean
#__eq__ means equals and must return a boolean

    def __lt__(self, other):
        return self.__client_id < other.__client_id

    def __eq__(self, other):
        return self.__client_id == other.__client_id

    #str method called when print
    def __str__(self):
        return str(self.__client_id) + "," + self.__last_name + "," + self.__first_name

    #getters and setters
    def get_client_id(self):
        return self.__client_id

    def set_client_id(self, client_id):
        self.__client_id = client_id

    def get_client_id(self):
        return self.__first_name

    def set_client_id(self, client_id):
        self.__first_name = first_name
    
    def get_client_id(self):
        return self.__last_name

    def set_client_id(self, client_id):
        self.__last_name = last_name
    
    def get_client_id(self):
        return self.__phone

    def set_client_id(self, client_id):
        self.__phone = phone

    def get_client_id(self):
        return self.email

    def set_client_id(self, client_id):
        self.__email = email